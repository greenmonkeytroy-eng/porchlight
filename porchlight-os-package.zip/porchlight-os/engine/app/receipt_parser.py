"""
Porchlight OS — OCR Receipt Parser & Pantry Ingestion Pipeline (v2)
System: Porchlight Digital Twin Engine
Function: Converts scanned paper/digital receipts into structured item logs with confidence scoring and DR-AIS logging.
"""

import os
import re
import json
import datetime
import logging
from typing import Dict, Any, List

logger = logging.getLogger("PorchlightOCR")
logging.basicConfig(level=logging.INFO, format="%(asctime)s - [Porchlight-OCR] - %(levelname)s - %(message)s")

class PorchlightReceiptParser:
    def __init__(self, confidence_threshold: float = 0.70):
        self.confidence_threshold = confidence_threshold

    def parse_raw_receipt_text(self, text: str) -> Dict[str, Any]:
        """Parses raw receipt OCR text into structured merchant, date, and line items."""
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        
        merchant = lines[0] if lines else "Unknown Merchant"
        
        # Regex search for dates (YYYY-MM-DD or MM/DD/YYYY)
        date_match = re.search(r"(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4})", text)
        receipt_date = date_match.group(1) if date_match else datetime.date.today().isoformat()

        items = []
        # Pattern matching item lines (e.g. "WHOLE MILK 2L $3.50")
        item_pattern = re.compile(r"^([A-Za-z0-9\s\(\)\.\-]+)\s+\$?(\d+\.\d{2})$")

        for line in lines[1:]:
            match = item_pattern.match(line)
            if match:
                item_name = match.group(1).strip()
                price = float(match.group(2))
                
                # Exclude summary lines like "SUBTOTAL", "TOTAL", "TAX", "VISA"
                if any(kw in item_name.upper() for kw in ["SUBTOTAL", "TOTAL", "TAX", "BALANCE", "CHANGE", "VISA", "MASTERCARD", "DEBIT"]):
                    continue
                
                # Confidence score based on string length and format
                confidence = round(0.85 if len(item_name) > 3 else 0.60, 2)
                
                items.append({
                    "raw_item_name": item_name,
                    "price_usd": price,
                    "confidence_score": confidence,
                    "requires_human_review": confidence < self.confidence_threshold
                })

        total_spend = sum(i["price_usd"] for i in items)

        return {
            "merchant": merchant,
            "receipt_date": receipt_date,
            "parsed_items_count": len(items),
            "total_calculated_spend_usd": round(total_spend, 2),
            "items": items
        }

    def emit_drais_ocr_record(self, parsed_data: Dict[str, Any], log_dir: str = "logs"):
        """Emits an immutable DR-AIS Decision Record for receipt parsing and validation."""
        os.makedirs(log_dir, exist_ok=True)
        timestamp = datetime.datetime.utcnow().isoformat() + "Z"

        record = {
            "system": "Porchlight OS",
            "component": "porchlight-engine/receipt_parser",
            "drais_version": "1.0",
            "timestamp": timestamp,
            "event_type": "RECEIPT_OCR_PARSING_AND_INGESTION",
            "inputs": {
                "merchant": parsed_data["merchant"],
                "receipt_date": parsed_data["receipt_date"],
                "parsed_items_count": parsed_data["parsed_items_count"]
            },
            "parsed_output": parsed_data,
            "governance": {
                "human_review_required": any(i["requires_human_review"] for i in parsed_data["items"]),
                "confidence_threshold_applied": self.confidence_threshold,
                "privacy_scope": "LOCAL_NETWORK_ONLY"
            }
        }

        filename = os.path.join(log_dir, f"dr_ais_ocr_{datetime.date.today().strftime('%Y%m%d')}.json")
        with open(filename, "w") as f:
            json.dump(record, f, indent=2)

        logger.info(f"Porchlight OCR DR-AIS Record written to {filename}")
        return record

if __name__ == "__main__":
    parser = PorchlightReceiptParser()
    
    # Mock Raw Receipt Text
    mock_ocr_receipt = """
    WHOLE FOODS MARKET
    DATE: 2026-10-06
    ORGANIC MILK 2L $4.50
    ROLLED OATS 1KG $3.80
    CHICKEN BREAST 1KG $11.50
    SUBTOTAL $19.80
    TAX $0.00
    TOTAL $19.80
    """
    
    result = parser.parse_raw_receipt_text(mock_ocr_receipt)
    print("\n=== Porchlight OCR Receipt Ingestion ===")
    print(f"Merchant: {result['merchant']}")
    print(f"Date:     {result['receipt_date']}")
    print(f"Items:    {result['parsed_items_count']}")
    print(f"Total:    ${result['total_calculated_spend_usd']}\n")
    
    for item in result["items"]:
        print(f"• {item['raw_item_name']} -> ${item['price_usd']} (Confidence: {item['confidence_score']})")
    
    parser.emit_drais_ocr_record(result)
