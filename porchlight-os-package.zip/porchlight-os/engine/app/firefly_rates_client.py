"""
Porchlight OS — Fixed House Costs & Rates Allocator (v2)
System: Porchlight Digital Twin Engine
Function: Manages municipal council rates, HOA/strata levies, insurance, standing utility fees, PFOR/EUR metrics, and occupant settlements.
"""

import os
import json
import datetime
import logging
from typing import Dict, Any, List

logger = logging.getLogger("PorchlightRates")
logging.basicConfig(level=logging.INFO, format="%(asctime)s - [Porchlight-Rates] - %(levelname)s - %(message)s")

class PorchlightRatesClient:
    def __init__(self, firefly_url: str = None, api_key: str = None):
        self.firefly_url = firefly_url or os.getenv("FIREFLY_URL", "http://localhost:8080")
        self.api_key = api_key or os.getenv("FIREFLY_API_KEY", "mock_porchlight_key")

    def fetch_monthly_fixed_costs(self) -> Dict[str, float]:
        """Ingests recurring house-associated fixed costs."""
        return {
            "council_rates_monthly": 220.00,
            "strata_hoa_levy_monthly": 350.00,
            "building_insurance_monthly": 140.00,
            "electricity_standing_supply_charge": 45.00,
            "water_standing_connection_charge": 35.00,
            "internet_broadband_fixed": 80.00
        }

    def calculate_pfor_and_eur(
        self, 
        fixed_costs: Dict[str, float], 
        total_monthly_spend: float, 
        utility_variable_spend: float, 
        kwh_consumed: float
    ) -> Dict[str, float]:
        """
        Calculates key house-associated targeting system benchmarks:
        - Property Fixed Overhead Ratio (PFOR)
        - Effective Utility Rate (EUR)
        """
        total_fixed_overhead = sum(fixed_costs.values())
        pfor_percent = (total_fixed_overhead / total_monthly_spend * 100) if total_monthly_spend > 0 else 0.0
        
        electricity_fixed = fixed_costs["electricity_standing_supply_charge"]
        total_elec_spend = electricity_fixed + utility_variable_spend
        effective_rate_per_kwh = (total_elec_spend / kwh_consumed) if kwh_consumed > 0 else 0.0

        return {
            "total_fixed_house_overhead_usd": round(total_fixed_overhead, 2),
            "pfor_percentage": round(pfor_percent, 2),
            "effective_utility_rate_per_kwh": round(effective_rate_per_kwh, 4)
        }

    def calculate_occupant_settlement(
        self, 
        fixed_costs: Dict[str, float], 
        occupants: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Distributes fixed house overhead pro-rata and calculates net monthly balances."""
        total_fixed_overhead = sum(fixed_costs.values())
        total_occupants = len(occupants)
        per_person_fixed_share = total_fixed_overhead / total_occupants if total_occupants > 0 else 0.0

        settlements = []
        for occ in occupants:
            net_total = occ["direct_spending"] + per_person_fixed_share + occ["submetered_utility"]
            settlements.append({
                "occupant_id": occ["id"],
                "name": occ["name"],
                "direct_personal_spend": occ["direct_spending"],
                "fixed_overhead_share": round(per_person_fixed_share, 2),
                "submetered_utility_spend": occ["submetered_utility"],
                "total_monthly_due_usd": round(net_total, 2)
            })
        return settlements

    def emit_drais_rates_record(self, fixed_costs: Dict[str, float], benchmarks: Dict[str, float], settlements: List[Dict[str, Any]], log_dir: str = "logs"):
        """Emits an immutable DR-AIS Decision Record for rates and house costs."""
        os.makedirs(log_dir, exist_ok=True)
        timestamp = datetime.datetime.utcnow().isoformat() + "Z"

        record = {
            "system": "Porchlight OS",
            "component": "porchlight-engine/rates_allocator",
            "drais_version": "1.0",
            "timestamp": timestamp,
            "event_type": "PROPERTY_OVERHEAD_AND_SETTLEMENT_CALCULATION",
            "inputs": {
                "fixed_house_costs": fixed_costs,
                "occupant_count": len(settlements)
            },
            "targeting_systems_calculated": benchmarks,
            "occupant_settlement_ledger": settlements,
            "governance": {
                "privacy_scope": "LOCAL_NETWORK_ONLY",
                "auditable_by_all_occupants": True,
                "human_override_available": True
            }
        }

        filename = os.path.join(log_dir, f"dr_ais_rates_{datetime.date.today().strftime('%Y%m%d')}.json")
        with open(filename, "w") as f:
            json.dump(record, f, indent=2)

        logger.info(f"Porchlight Fixed Overhead DR-AIS Record written to {filename}")
        return record

if __name__ == "__main__":
    rates_client = PorchlightRatesClient()
    fixed_costs = rates_client.fetch_monthly_fixed_costs()
    
    # Example scenario: $2,800 total household monthly spend, $180 variable power, 600 kWh
    benchmarks = rates_client.calculate_pfor_and_eur(fixed_costs, total_monthly_spend=2800.00, utility_variable_spend=180.00, kwh_consumed=600.0)
    
    occupants = [
        {"id": "OCC_A", "name": "Occupant A", "direct_spending": 420.00, "submetered_utility": 95.00},
        {"id": "OCC_B", "name": "Occupant B", "direct_spending": 310.00, "submetered_utility": 85.00}
    ]
    
    settlements = rates_client.calculate_occupant_settlement(fixed_costs, occupants)

    print("\n=== Porchlight Property & Fixed House Overhead Ledger ===")
    print(f"Total Fixed House Overhead: ${benchmarks['total_fixed_house_overhead_usd']}/mo")
    print(f"Property Fixed Overhead Ratio (PFOR): {benchmarks['pfor_percentage']}%")
    print(f"Effective Utility Rate (EUR): ${benchmarks['effective_utility_rate_per_kwh']}/kWh\n")

    print("--- Per-Occupant Monthly Settlement ---")
    for s in settlements:
        print(f"• {s['name']}: Personal Direct (${s['direct_personal_spend']}) + Fixed Share (${s['fixed_overhead_share']}) + Power (${s['submetered_utility_spend']}) = Total Due: ${s['total_monthly_due_usd']}")
    
    rates_client.emit_drais_rates_record(fixed_costs, benchmarks, settlements)
