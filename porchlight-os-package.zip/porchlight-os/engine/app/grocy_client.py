"""
Porchlight OS — Grocy Pantry API Client & Metrics Calculator (v2)
System: Porchlight Digital Twin Engine
Function: Synchronizes Grocy inventory, computes Cost per 2k kcal, logs DR-AIS decision records.
"""

import os
import json
import datetime
import logging
from typing import Dict, Any, List

import requests

# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - [Porchlight-Grocy] - %(levelname)s - %(message)s")
logger = logging.getLogger("PorchlightGrocy")

class PorchlightGrocyClient:
    def __init__(self, base_url: str = None, api_key: str = None):
        self.base_url = base_url or os.getenv("GROCY_URL", "http://localhost:9283")
        self.api_key = api_key or os.getenv("GROCY_API_KEY", "mock_porchlight_key")
        self.headers = {
            "GROCY-API-KEY": self.api_key,
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

    def fetch_stock_overview(self) -> List[Dict[str, Any]]:
        """Fetch current stock overview from Grocy API."""
        endpoint = f"{self.base_url}/api/objects/stock"
        logger.info(f"Connecting to Porchlight Grocy instance at {self.base_url}...")
        
        try:
            response = requests.get(endpoint, headers=self.headers, timeout=5)
            if response.status_code == 200:
                return response.json()
        except requests.exceptions.RequestException as e:
            logger.warning(f"Unable to connect to live Grocy API ({e}). Using Porchlight mock pantry data.")
        
        # Mock Porchlight Pantry Data for Local Testing
        return [
            {"product_id": 101, "name": "Organic Whole Milk (2L)", "amount": 2, "price_per_unit": 3.50, "calories_per_unit": 1200, "best_before_date": (datetime.date.today() + datetime.timedelta(days=1)).isoformat()},
            {"product_id": 102, "name": "Rolled Oats (1kg)", "amount": 3, "price_per_unit": 4.00, "calories_per_unit": 3800, "best_before_date": "2026-12-31"},
            {"product_id": 103, "name": "Chicken Breast (1kg)", "amount": 1.5, "price_per_unit": 11.00, "calories_per_unit": 1650, "best_before_date": (datetime.date.today() + datetime.timedelta(days=2)).isoformat()},
            {"product_id": 104, "name": "Avocados (Mesh Bag)", "amount": 1, "price_per_unit": 5.00, "calories_per_unit": 800, "best_before_date": "2026-10-15"}
        ]

    def calculate_pantry_metrics(self, stock: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculates total inventory valuation, total calories, and Cost per 2,000 kcal benchmark."""
        total_val = sum(item["amount"] * item["price_per_unit"] for item in stock)
        total_cal = sum(item["amount"] * item["calories_per_unit"] for item in stock)
        
        cost_per_2k = (total_val / total_cal * 2000) if total_cal > 0 else 0.0

        expiring_soon = [
            item["name"] for item in stock 
            if item.get("best_before_date") and item["best_before_date"] <= (datetime.date.today() + datetime.timedelta(days=3)).isoformat()
        ]

        return {
            "total_items": len(stock),
            "inventory_value_usd": round(total_val, 2),
            "total_calories_kcal": round(total_cal, 0),
            "cost_per_2000_kcal_usd": round(cost_per_2k, 2),
            "expiring_soon_count": len(expiring_soon),
            "expiring_items": expiring_soon
        }

    def emit_drais_decision_record(self, metrics: Dict[str, Any], log_dir: str = "logs"):
        """Emits an immutable Decision Record for AI Systems (DR-AIS) log for Porchlight governance."""
        os.makedirs(log_dir, exist_ok=True)
        timestamp = datetime.datetime.utcnow().isoformat() + "Z"
        
        drais_record = {
            "system": "Porchlight OS",
            "component": "porchlight-engine/grocy_client",
            "drais_version": "1.0",
            "timestamp": timestamp,
            "event_type": "PANTRY_NUTRITION_METRICS_EVALUATION",
            "inputs": {
                "active_pantry_items_count": metrics["total_items"],
                "inventory_value_usd": metrics["inventory_value_usd"],
                "total_calories_kcal": metrics["total_calories_kcal"]
            },
            "targeting_systems_calculated": {
                "cost_per_2000_kcal": metrics["cost_per_2000_kcal_usd"],
                "expiring_soon_count": metrics["expiring_soon_count"]
            },
            "recommendation_engine": {
                "action_required": metrics["expiring_soon_count"] > 0,
                "suggested_action": f"Generate meal plan prioritizing expiring items: {', '.join(metrics['expiring_items'])}" if metrics["expiring_soon_count"] > 0 else "Inventory stable."
            },
            "governance": {
                "privacy_scope": "LOCAL_NETWORK_ONLY",
                "human_override_available": True
            }
        }

        filename = os.path.join(log_dir, f"dr_ais_grocy_{datetime.date.today().strftime('%Y%m%d')}.json")
        with open(filename, "w") as f:
            json.dump(drais_record, f, indent=2)
        
        logger.info(f"DR-AIS Decision Record successfully written to {filename}")
        return drais_record

if __name__ == "__main__":
    client = PorchlightGrocyClient()
    stock_data = client.fetch_stock_overview()
    metrics = client.calculate_pantry_metrics(stock_data)
    
    print("\n--- Porchlight Pantry Scoreboard ---")
    print(f"Total Pantry Items:       {metrics['total_items']}")
    print(f"Inventory Valuation:       ${metrics['inventory_value_usd']}")
    print(f"Total Caloric Stock:       {metrics['total_calories_kcal']} kcal")
    print(f"Targeting System ($/2k):   ${metrics['cost_per_2000_kcal_usd']} / 2,000 kcal")
    print(f"Expiring Items (3 days):   {metrics['expiring_items']}\n")
    
    client.emit_drais_drais_record = client.emit_drais_decision_record(metrics)
